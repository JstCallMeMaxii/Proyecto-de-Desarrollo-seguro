# pyrefly: ignore-errors
from datetime import datetime
from flask import Blueprint, jsonify, request  # pyrefly: ignore [missing-import]  # type: ignore
from bson import ObjectId  # pyrefly: ignore [missing-import]  # type: ignore
from bson.errors import InvalidId  # pyrefly: ignore [missing-import]  # type: ignore
from db_mongo import figuras, serialize_doc

# Creación del Blueprint de figuras (faltaba en el proyecto original)
figuras_bp = Blueprint("figuras_bp", __name__)


@figuras_bp.route("", methods=["GET"])
@figuras_bp.route("/", methods=["GET"])
def obtener_figuras():
    """
    Obtener todas las figuras.
    Permite filtrar por categoría a través de query params: ?categoria=Anime
    Por defecto solo devuelve figuras activas; usar ?incluir_inactivas=true para verlas todas.
    """
    try:
        query = {}
        categoria_param = request.args.get("categoria")
        if categoria_param:
            query["categoria_nombre"] = categoria_param

        if request.args.get("incluir_inactivas") != "true":
            query["activo"] = True

        lista_figuras = list(figuras.find(query))
        return jsonify({
            "total": len(lista_figuras),
            "figuras": serialize_doc(lista_figuras)
        }), 200
    except Exception as e:
        return jsonify({"error": f"Error al obtener figuras: {str(e)}"}), 500


@figuras_bp.route("/<string:figura_id>", methods=["GET"])
def obtener_figura_por_id(figura_id):
    """
    Obtener una figura específica por su ObjectId.
    """
    try:
        if not ObjectId.is_valid(figura_id):
            return jsonify({"error": "ID de figura inválido"}), 400

        figura = figuras.find_one({"_id": ObjectId(figura_id)})
        if not figura:
            return jsonify({"error": "Figura no encontrada"}), 404

        return jsonify({"figura": serialize_doc(figura)}), 200
    except Exception as e:
        return jsonify({"error": f"Error al buscar figura: {str(e)}"}), 500


@figuras_bp.route("", methods=["POST"])
@figuras_bp.route("/", methods=["POST"])
def crear_figura():
    """
    Crear una nueva figura 3D.
    """
    try:
        data = request.get_json() or {}

        nombre = data.get("nombre")
        precio = data.get("precio")

        if not nombre or precio is None:
            return jsonify({
                "error": "Los campos 'nombre' y 'precio' son requeridos"
            }), 400

        try:
            precio = float(precio)
            stock = int(data.get("stock", 0))
        except (ValueError, TypeError):
            return jsonify({"error": "'precio' o 'stock' tienen un formato inválido"}), 400

        if precio < 0 or stock < 0:
            return jsonify({"error": "'precio' y 'stock' no pueden ser negativos"}), 400

        nueva_figura = {
            "nombre": nombre.strip(),
            "descripcion": data.get("descripcion", ""),
            "precio": precio,
            "stock": stock,
            "material": data.get("material", ""),
            "escala": data.get("escala", ""),
            "categoria": data.get("categoria_nombre", ""),
            "imagen_url": data.get("imagen_url", ""),
            "creado_por": data.get("creado_por"),
            "activo": data.get("activo", True),
            "fecha_creacion": datetime.utcnow().isoformat()
        }

        resultado = figuras.insert_one(nueva_figura)
        nueva_figura["_id"] = resultado.inserted_id

        return jsonify({
            "mensaje": "Figura creada exitosamente",
            "figura": serialize_doc(nueva_figura)
        }), 201

    except Exception as e:
        return jsonify({"error": f"Error al crear figura: {str(e)}"}), 500


@figuras_bp.route("/<string:figura_id>", methods=["PUT"])
def actualizar_figura(figura_id):
    """
    Actualizar datos de una figura por su ObjectId.
    """
    try:
        if not ObjectId.is_valid(figura_id):
            return jsonify({"error": "ID de figura inválido"}), 400

        data = request.get_json() or {}
        if not data:
            return jsonify({"error": "No se enviaron datos para actualizar"}), 400

        if "precio" in data:
            try:
                data["precio"] = float(data["precio"])
                if data["precio"] < 0:
                    return jsonify({"error": "'precio' no puede ser negativo"}), 400
            except (ValueError, TypeError):
                return jsonify({"error": "'precio' tiene un formato inválido"}), 400

        if "stock" in data:
            try:
                data["stock"] = int(data["stock"])
                if data["stock"] < 0:
                    return jsonify({"error": "'stock' no puede ser negativo"}), 400
            except (ValueError, TypeError):
                return jsonify({"error": "'stock' tiene un formato inválido"}), 400

        data.pop("_id", None)
        data["fecha_actualizacion"] = datetime.utcnow().isoformat()

        resultado = figuras.update_one(
            {"_id": ObjectId(figura_id)},
            {"$set": data}
        )

        if resultado.matched_count == 0:
            return jsonify({"error": "Figura no encontrada"}), 404

        figura_actualizada = figuras.find_one({"_id": ObjectId(figura_id)})
        return jsonify({
            "mensaje": "Figura actualizada con éxito",
            "figura": serialize_doc(figura_actualizada)
        }), 200

    except Exception as e:
        return jsonify({"error": f"Error al actualizar figura: {str(e)}"}), 500


@figuras_bp.route("/<string:figura_id>", methods=["DELETE"])
def eliminar_figura(figura_id):
    """
    Eliminar una figura por su ObjectId.
    """
    try:
        if not ObjectId.is_valid(figura_id):
            return jsonify({"error": "ID de figura inválido"}), 400

        resultado = figuras.delete_one({"_id": ObjectId(figura_id)})
        if resultado.deleted_count == 0:
            return jsonify({"error": "Figura no encontrada"}), 404

        return jsonify({"mensaje": f"Figura con ID {figura_id} eliminada exitosamente"}), 200
    except Exception as e:
        return jsonify({"error": f"Error al eliminar figura: {str(e)}"}), 500