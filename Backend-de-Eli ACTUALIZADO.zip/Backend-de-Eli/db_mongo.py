# pyrefly: ignore-errors
import os
from datetime import date, datetime
from dotenv import load_dotenv  # pyrefly: ignore [missing-import]  # type: ignore
from pymongo import MongoClient  # pyrefly: ignore [missing-import]  # type: ignore
from bson import ObjectId  # pyrefly: ignore [missing-import]  # type: ignore

# Cargar variables de entorno desde el archivo .env
load_dotenv()

# Obtener variables de conexión
MONGO_URI = os.getenv(
    "MONGO_URI",
    "mongodb+srv://admin_tienda:1234@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority"
)
DB_NAME = os.getenv("DB_NAME", "tienda_3d_db")

# Conexión al cliente de MongoDB Atlas
client = MongoClient(MONGO_URI)
db = client[DB_NAME]

# Exportación de colecciones para la tienda de figuras 3D
usuarios = db["usuarios"]
figuras = db["figuras"]
pedidos = db["pedidos"]


def serialize_doc(doc):
    """
    Función helper recursiva para serializar documentos de MongoDB a formato JSON.
    Convierte ObjectId en str y maneja tipos datetime/date así como subdocumentos
    y arreglos anidados (como los ítems embebidos en los pedidos).
    """
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_doc(item) for item in doc]
    if isinstance(doc, dict):
        serialized = {}
        for key, value in doc.items():
            if isinstance(value, ObjectId):
                serialized[key] = str(value)
            elif isinstance(value, (datetime, date)):
                serialized[key] = value.isoformat()
            elif isinstance(value, (dict, list)):
                serialized[key] = serialize_doc(value)
            else:
                serialized[key] = value
        return serialized
    if isinstance(doc, ObjectId):
        return str(doc)
    if isinstance(doc, (datetime, date)):
        return doc.isoformat()
    return doc
