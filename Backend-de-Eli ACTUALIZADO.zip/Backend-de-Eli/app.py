# pyrefly: ignore-errors
import os
from flask import Flask, jsonify  # pyrefly: ignore [missing-import]  # type: ignore
from flask_cors import CORS  # pyrefly: ignore [missing-import]  # type: ignore
from dotenv import load_dotenv  # pyrefly: ignore [missing-import]  # type: ignore

# Cargar variables de entorno desde .env
load_dotenv()

# Importar Blueprints de usuarios, pedidos y figuras
from usuarios_mongo_routes import usuarios_bp
from pedidos_mongo_routes import pedidos_bp
from figuras_mongo_routes import figuras_bp  # CORRECCIÓN: no estaba importado

# Inicialización de la aplicación Flask
app = Flask(__name__)

# Configuración de CORS para permitir conexiones desde clientes frontend y servidores Node.js / Express
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

# Registro de Blueprints con prefijos de ruta
# Registro de Blueprints con prefijos de ruta
app.register_blueprint(usuarios_bp, url_prefix="/api/usuarios")
app.register_blueprint(pedidos_bp, url_prefix="/api/pedidos")
app.register_blueprint(figuras_bp, url_prefix="/api/figuras")  # CORRECCIÓN: no estaba registrado


@app.route("/", methods=["GET"])
@app.route("/api", methods=["GET"])
def index():
    """
    Ruta raíz para verificar el estado de la API y documentar endpoints disponibles.
    """
    return jsonify({
        "status": "online",
        "servicio": "Backend Tienda Figuras 3D (Flask + PyMongo)",
        "puerto": 5000,
        "endpoints": {
            "usuarios": {
                "obtener_todos": "GET /api/usuarios (soporta ?rol=admin|vendedor|cliente)",
                "obtener_uno": "GET /api/usuarios/<id>",
                "crear": "POST /api/usuarios",
                "actualizar": "PUT /api/usuarios/<id>",
                "eliminar": "DELETE /api/usuarios/<id>",
                "login": "POST /api/usuarios/login"
            },
            "figuras": {
                "obtener_todas": "GET /api/figuras (soporta ?categoria=X, ?activo=todas)",
                "obtener_una": "GET /api/figuras/<id>",
                "crear": "POST /api/figuras",
                "actualizar": "PUT /api/figuras/<id>",
                "eliminar": "DELETE /api/figuras/<id>"
            },
            "pedidos": {
                "obtener_todos": "GET /api/pedidos (soporta ?usuario_id=X&estado=Y)",
                "obtener_uno": "GET /api/pedidos/<id>",
                "pedidos_usuario": "GET /api/pedidos/usuario/<usuario_id>",
                "crear": "POST /api/pedidos (con ítems embebidos)",
                "actualizar": "PUT /api/pedidos/<id>",
                "eliminar": "DELETE /api/pedidos/<id>"
            }
        }
    }), 200


@app.errorhandler(404)
def recurso_no_encontrado(error):
    return jsonify({"error": "Ruta o recurso no encontrado", "codigo": 404}), 404


@app.errorhandler(500)
def error_interno(error):
    return jsonify({"error": "Error interno del servidor", "codigo": 500}), 500


if __name__ == "__main__":
    puerto = int(os.getenv("PORT", 5000))
    print(f"🚀 Servidor Flask corriendo en http://localhost:{puerto}")
    app.run(host="0.0.0.0", port=puerto, debug=True)
