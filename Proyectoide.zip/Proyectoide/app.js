const express = require("express");
const path = require("path");
const crypto = require("crypto");
const axios = require("axios");

const sesiones = {};

const API_URL = "http://localhost:5000";

const app = express();
const PORT = 3000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));

function parseCookies(req) {
  const header = req.headers.cookie;
  const cookies = {};
  if (header) {
    header.split(";").forEach((cookie) => {
      const partes = cookie.trim().split("=");
      const clave = partes.shift();
      const valor = partes.join("=");
      if (clave) cookies[clave] = decodeURIComponent(valor);
    });
  }
  return cookies;
}

function manejarSesion(req, res, next) {
  const cookies = parseCookies(req);
  let sid = cookies.sid;

  if (!sid || !sesiones[sid]) {
    sid = crypto.randomUUID();
    sesiones[sid] = {};
    res.cookie("sid", sid, {
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 1 día
    });
  }

  req.session = sesiones[sid];
  req.sessionId = sid;
  next();
}
app.use(manejarSesion);

// Normaliza un documento de figura venido de la API (tolera "Nombre" con
// mayúscula y campos opcionales ausentes en documentos cargados a mano).
function normalizarFigura(f) {
  return {
    id: f._id,
    nombre: f.nombre || f.Nombre || "(sin nombre)",
    descripcion: f.descripcion || "",
    precio: f.precio,
    stock: f.stock,
    material: f.material || "",
    escala: f.escala || "",
    categoria_nombre: f.categoria_nombre || f.categoria || null,
    activo: f.activo !== false,
  };
}

const USUARIOS_DEMO = [
  { id: "u1", nombre: "Administrador", email: "admin@tienda3d.cl", password: "admin123", rol: "admin", activo: true },
  { id: "u2", nombre: "Vendedor Uno", email: "vendedor@tienda3d.cl", password: "vendedor123", rol: "vendedor", activo: true },
  { id: "u3", nombre: "Cliente Demo", email: "cliente@tienda3d.cl", password: "cliente123", rol: "cliente", activo: true },
];

let PEDIDOS_DEMO = [];
let siguientePedidoId = 1;

function cargarUsuarioActual(req, res, next) {
  req.usuario = null;
  if (req.session.usuarioId) {
    req.usuario = USUARIOS_DEMO.find((u) => u.id === req.session.usuarioId) || null;
  }
  res.locals.usuario = req.usuario;
  next();
}
app.use(cargarUsuarioActual);

function loginRequerido(req, res, next) {
  if (!req.usuario) {
    return res.redirect("/login");
  }
  next();
}

function rolesRequeridos(...rolesPermitidos) {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.redirect("/login");
    }
    if (!rolesPermitidos.includes(req.usuario.rol)) {
      return res.status(403).send("No tienes permisos para acceder a esta sección.");
    }
    next();
  };
}

// ---------- Catálogo (público) ----------

app.get("/", async (req, res) => {
  try {
    const respuesta = await axios.get(`${API_URL}/api/figuras`);
    const crudas = Array.isArray(respuesta.data) ? respuesta.data : respuesta.data.figuras || [];
    const figuras = crudas.map(normalizarFigura).filter((f) => f.activo);

    res.render("index", { figuras, titulo: "Catálogo - Tienda3D" });
  } catch (error) {
    console.error("Error al obtener figuras desde Flask:", error.message);
    res.render("index", { figuras: [], titulo: "Catálogo - Tienda3D" });
  }
});

// ---------- Autenticación (todavía con USUARIOS_DEMO) ----------

app.get("/login", (req, res) => {
  res.render("login", { titulo: "Iniciar sesión - Tienda3D", error: null });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const usuario = USUARIOS_DEMO.find(
    (u) => u.email === email.toLowerCase() && u.password === password
  );
  if (!usuario) {
    return res.render("login", {
      titulo: "Iniciar sesión - Tienda3D",
      error: "Correo o contraseña incorrectos.",
    });
  }
  req.session.usuarioId = usuario.id;
  res.redirect("/");
});

app.get("/registro", (req, res) => {
  res.render("registro", { titulo: "Crear cuenta - Tienda3D", error: null });
});

app.post("/registro", (req, res) => {
  const { nombre, email, password } = req.body;
  const existe = USUARIOS_DEMO.find((u) => u.email === email.toLowerCase());
  if (existe) {
    return res.render("registro", {
      titulo: "Crear cuenta - Tienda3D",
      error: "Ese correo ya está registrado.",
    });
  }
  const nuevoUsuario = {
    id: "u" + (USUARIOS_DEMO.length + 1),
    nombre,
    email: email.toLowerCase(),
    password,
    rol: "cliente",
    activo: true,
  };
  USUARIOS_DEMO.push(nuevoUsuario);
  req.session.usuarioId = nuevoUsuario.id;
  res.redirect("/");
});

app.get("/logout", (req, res) => {
  delete sesiones[req.sessionId];
  res.redirect("/");
});

// ---------- CRUD de Figuras (ahora 100% contra la API real) ----------

app.get("/figuras", loginRequerido, async (req, res) => {
  try {
    const respuesta = await axios.get(`${API_URL}/api/figuras?activo=todas`);
    const crudas = Array.isArray(respuesta.data) ? respuesta.data : respuesta.data.figuras || [];
    const figuras = crudas.map(normalizarFigura);

    res.render("figuras_lista", { titulo: "Figuras - Tienda3D", figuras });
  } catch (error) {
    console.error("Error al obtener figuras desde Flask:", error.message);
    res.status(500).send("No se pudieron obtener las figuras. ¿Está corriendo tu backend Flask?");
  }
});

app.get("/figuras/nueva", rolesRequeridos("admin", "vendedor"), (req, res) => {
  res.render("figura_form", { titulo: "Nueva figura - Tienda3D", figura: null });
});

app.post("/figuras/nueva", rolesRequeridos("admin", "vendedor"), async (req, res) => {
  try {
    await axios.post(`${API_URL}/api/figuras`, {
      nombre: req.body.nombre,
      descripcion: req.body.descripcion || "",
      precio: parseFloat(req.body.precio),
      stock: parseInt(req.body.stock, 10),
      material: req.body.material || "",
      escala: req.body.escala || "",
      categoria_nombre: req.body.categoria_nombre || "",
      creado_por: req.usuario.id,
    });
    res.redirect("/figuras");
  } catch (error) {
    console.error("Error al crear figura:", error.message);
    res.status(500).send("No se pudo crear la figura.");
  }
});

app.get("/figuras/:id/editar", rolesRequeridos("admin", "vendedor"), async (req, res) => {
  try {
    const respuesta = await axios.get(`${API_URL}/api/figuras/${req.params.id}`);
    const figura = normalizarFigura(respuesta.data.figura || respuesta.data);
    res.render("figura_form", { titulo: "Editar figura - Tienda3D", figura });
  } catch (error) {
    console.error("Error al buscar figura:", error.message);
    res.redirect("/figuras");
  }
});

app.post("/figuras/:id/editar", rolesRequeridos("admin", "vendedor"), async (req, res) => {
  try {
    await axios.put(`${API_URL}/api/figuras/${req.params.id}`, {
      nombre: req.body.nombre,
      descripcion: req.body.descripcion || "",
      precio: parseFloat(req.body.precio),
      stock: parseInt(req.body.stock, 10),
      material: req.body.material || "",
      escala: req.body.escala || "",
      categoria_nombre: req.body.categoria_nombre || "",
      activo: req.body.activo === "on",
    });
    res.redirect("/figuras");
  } catch (error) {
    console.error("Error al actualizar figura:", error.message);
    res.status(500).send("No se pudo actualizar la figura.");
  }
});

app.post("/figuras/:id/eliminar", rolesRequeridos("admin", "vendedor"), async (req, res) => {
  try {
    await axios.delete(`${API_URL}/api/figuras/${req.params.id}`);
    res.redirect("/figuras");
  } catch (error) {
    console.error("Error al eliminar figura:", error.message);
    res.status(500).send("No se pudo eliminar la figura.");
  }
});

// ---------- Carrito y pedidos (figura viene de la API; pedido sigue en memoria) ----------

app.post("/carrito/agregar/:id", rolesRequeridos("cliente"), (req, res) => {
  if (!req.session.carrito) req.session.carrito = {};
  const id = req.params.id;
  req.session.carrito[id] = (req.session.carrito[id] || 0) + 1;
  res.redirect("/");
});

app.get("/carrito", rolesRequeridos("cliente"), async (req, res) => {
  const carrito = req.session.carrito || {};
  const items = [];
  let total = 0;

  for (const [figuraId, cantidad] of Object.entries(carrito)) {
    try {
      const respuesta = await axios.get(`${API_URL}/api/figuras/${figuraId}`);
      const figura = normalizarFigura(respuesta.data.figura || respuesta.data);
      const subtotal = figura.precio * cantidad;
      total += subtotal;
      items.push({ figura, cantidad, subtotal });
    } catch (error) {
      console.error(`Figura ${figuraId} ya no existe, se omite del carrito.`);
    }
  }

  res.render("carrito", { titulo: "Carrito - Tienda3D", items, total });
});

app.post("/carrito/confirmar", rolesRequeridos("cliente"), async (req, res) => {
  const carrito = req.session.carrito || {};
  if (Object.keys(carrito).length === 0) return res.redirect("/carrito");

  let total = 0;
  const itemsPedido = [];

  for (const [figuraId, cantidad] of Object.entries(carrito)) {
    try {
      const respuesta = await axios.get(`${API_URL}/api/figuras/${figuraId}`);
      const figura = normalizarFigura(respuesta.data.figura || respuesta.data);
      const subtotal = figura.precio * cantidad;
      total += subtotal;
      itemsPedido.push({ figura_id: figuraId, nombre: figura.nombre, cantidad, precio_unitario: figura.precio });
    } catch (error) {
      console.error(`Figura ${figuraId} ya no existe, se omite del pedido.`);
    }
  }

  PEDIDOS_DEMO.push({
    id: "p" + siguientePedidoId++,
    cliente_id: req.usuario.id,
    cliente_nombre: req.usuario.nombre,
    cliente_email: req.usuario.email,
    estado: "pendiente",
    total,
    items: itemsPedido,
    creado_en: new Date().toLocaleString("es-CL"),
  });

  req.session.carrito = {};
  res.redirect("/mis-pedidos");
});

app.get("/mis-pedidos", rolesRequeridos("cliente"), (req, res) => {
  const pedidos = PEDIDOS_DEMO.filter((p) => p.cliente_id === req.usuario.id);
  res.render("mis_pedidos", { titulo: "Mis pedidos - Tienda3D", pedidos });
});

app.get("/pedidos", rolesRequeridos("admin", "vendedor"), (req, res) => {
  res.render("pedidos_lista", { titulo: "Pedidos - Tienda3D", pedidos: PEDIDOS_DEMO });
});

app.post("/pedidos/:id/estado", rolesRequeridos("admin", "vendedor"), (req, res) => {
  const pedido = PEDIDOS_DEMO.find((p) => p.id === req.params.id);
  if (pedido) pedido.estado = req.body.estado;
  res.redirect("/pedidos");
});

app.get("/usuarios", rolesRequeridos("admin"), (req, res) => {
  res.render("usuarios_lista", { titulo: "Usuarios - Tienda3D", usuarios: USUARIOS_DEMO });
});

app.get("/usuarios/nuevo", rolesRequeridos("admin"), (req, res) => {
  res.render("usuario_form", { titulo: "Nuevo usuario - Tienda3D" });
});

app.post("/usuarios/nuevo", rolesRequeridos("admin"), (req, res) => {
  USUARIOS_DEMO.push({
    id: "u" + (USUARIOS_DEMO.length + 1),
    nombre: req.body.nombre,
    email: req.body.email.toLowerCase(),
    password: req.body.password,
    rol: req.body.rol,
    activo: true,
  });
  res.redirect("/usuarios");
});

app.post("/usuarios/:id/toggle-activo", rolesRequeridos("admin"), (req, res) => {
  if (req.params.id === req.usuario.id) return res.redirect("/usuarios");
  const usuario = USUARIOS_DEMO.find((u) => u.id === req.params.id);
  if (usuario) usuario.activo = !usuario.activo;
  res.redirect("/usuarios");
});

app.listen(PORT, () => {
  console.log(`Frontend Node.js corriendo en http://localhost:${PORT}`);
});