# pyrefly: ignore-errors
from datetime import datetime
from flask import Blueprint, jsonify, request  # pyrefly: ignore [missing-import]  # type: ignore
from bson import ObjectId  # pyrefly: ignore [missing-import]  # type: ignore
from bson.errors import InvalidId  # pyrefly: ignore [missing-import]  # type: ignore
from db_mongo import pedidos, serialize_doc

# Creación del Blueprint de pedidos
pedidos_bp = Blueprint("pedidos_bp", __name__)

ESTADOS_VALIDOS = {"pendiente", "en_proceso", "pagado", "enviado", "entregado", "cancelado"}


@pedidos_bp.route("", methods=["GET"])
@pedidos_bp.route("/", methods=["GET"])
def obtener_pedidos():
    """
    Obtener lista de pedidos.
    Soporta filtros por query params:
      - ?usuario_id=<id>
      - ?estado=pendiente|pagado|enviado|...
    """
    try:
        filtro = {}
        usuario_id = request.args.get("usuario_id")
        estado = request.args.get("estado")

        if usuario_id:
            filtro["usuario_id"] = usuario_id
        if estado:
            filtro["estado"] = estado.lower()

        lista_pedidos = list(pedidos.find(filtro).sort("fecha_creacion", -1))
        return jsonify({
            "total": len(lista_pedidos),
            "pedidos": serialize_doc(lista_pedidos)
        }), 200
    except Exception as e:
        return jsonify({"error": f"Error al obtener pedidos: {str(e)}"}), 500


@pedidos_bp.route("/<string:pedido_id>", methods=["GET"])
def obtener_pedido_por_id(pedido_id):
    """
    Obtener los detalles de un pedido específico mediante su ObjectId.
    """
    try:
        if not ObjectId.is_valid(pedido_id):
            return jsonify({"error": "ID de pedido inválido"}), 400

        pedido = pedidos.find_one({"_id": ObjectId(pedido_id)})
        if not pedido:
            return jsonify({"error": "Pedido no encontrado"}), 404

        return jsonify({"pedido": serialize_doc(pedido)}), 200
    except Exception as e:
        return jsonify({"error": f"Error al buscar pedido: {str(e)}"}), 500


@pedidos_bp.route("/usuario/<string:usuario_id>", methods=["GET"])
def obtener_pedidos_por_usuario(usuario_id):
    """
    Obtener todos los pedidos realizados por un usuario en específico.
    """
    try:
        lista_pedidos = list(pedidos.find({"usuario_id": usuario_id}).sort("fecha_creacion", -1))
        return jsonify({
            "usuario_id": usuario_id,
            "total_pedidos": len(lista_pedidos),
            "pedidos": serialize_doc(lista_pedidos)
        }), 200
    except Exception as e:
        return jsonify({"error": f"Error al obtener pedidos del usuario: {str(e)}"}), 500


@pedidos_bp.route("", methods=["POST"])
@pedidos_bp.route("/", methods=["POST"])
def crear_pedido():
    """
    Crear un nuevo pedido guardando la lista de figuras 3D como un arreglo
    de ítems embebidos dentro del documento del pedido.
    """
    try:
        data = request.get_json() or {}

        usuario_id = data.get("usuario_id")
        items_raw = data.get("items")

        if not usuario_id:
            return jsonify({"error": "El campo 'usuario_id' es obligatorio"}), 400

        if not items_raw or not isinstance(items_raw, list) or len(items_raw) == 0:
            return jsonify({
                "error": "El pedido debe contener al menos un producto en el arreglo 'items'"
            }), 400

        # Procesar y normalizar los ítems embebidos
        items_embebidos = []
        total_calculado = 0.0

        for idx, item in enumerate(items_raw):
            if not isinstance(item, dict):
                return jsonify({"error": f"El ítem en la posición {idx} debe ser un objeto"}), 400

            figura_id = item.get("figura_id") or item.get("producto_id")
            nombre = item.get("nombre") or item.get("titulo", "Figura 3D")
            cantidad = item.get("cantidad", 1)
            precio_unitario = item.get("precio_unitario") or item.get("precio", 0.0)

            try:
                cantidad = int(cantidad)
                precio_unitario = float(precio_unitario)
            except (ValueError, TypeError):
                return jsonify({
                    "error": f"Cantidad o precio inválido en el ítem '{nombre}' (índice {idx})"
                }), 400

            if cantidad <= 0:
                return jsonify({"error": f"La cantidad del ítem '{nombre}' debe ser mayor a 0"}), 400
            if precio_unitario < 0:
                return jsonify({"error": f"El precio del ítem '{nombre}' no puede ser negativo"}), 400

            subtotal = round(cantidad * precio_unitario, 2)
            total_calculado += subtotal

            # Estructura del ítem embebido
            item_embebido = {
                "figura_id": str(figura_id) if figura_id else None,
                "nombre": str(nombre).strip(),
                "cantidad": cantidad,
                "precio_unitario": round(precio_unitario, 2),
                "subtotal": subtotal,
                "material": item.get("material", "PLA"),  # Ejemplo característico de figuras 3D
                "color": item.get("color", "Original"),
                "escala": item.get("escala", "1:10")
            }
            items_embebidos.append(item_embebido)

        total_calculado = round(total_calculado, 2)
        total_final = float(data.get("total", total_calculado))

        # Estructura principal del documento de pedido con arreglo de ítems embebido
        nuevo_pedido = {
            "usuario_id": str(usuario_id),
            "cliente": data.get("cliente", {}),
            "items": items_embebidos,  # Arreglo de ítems embebidos
            "total": total_final,
            "estado": data.get("estado", "pendiente").lower(),
            "metodo_pago": data.get("metodo_pago", "tarjeta"),
            "direccion_envio": data.get("direccion_envio", {}),
            "notas": data.get("notas", ""),
            "fecha_creacion": datetime.utcnow().isoformat()
        }

        # Validar estado inicial si fue proporcionado
        if nuevo_pedido["estado"] not in ESTADOS_VALIDOS:
            nuevo_pedido["estado"] = "pendiente"

        resultado = pedidos.insert_one(nuevo_pedido)
        nuevo_pedido["_id"] = resultado.inserted_id

        return jsonify({
            "mensaje": "Pedido registrado exitosamente",
            "pedido": serialize_doc(nuevo_pedido)
        }), 201

    except Exception as e:
        return jsonify({"error": f"Error al registrar pedido: {str(e)}"}), 500


@pedidos_bp.route("/<string:pedido_id>", methods=["PUT"])
def actualizar_pedido(pedido_id):
    """
    Actualizar estado, dirección o ítems embebidos de un pedido.
    """
    try:
        if not ObjectId.is_valid(pedido_id):
            return jsonify({"error": "ID de pedido inválido"}), 400

        data = request.get_json() or {}
        if not data:
            return jsonify({"error": "No se proporcionaron datos para actualizar"}), 400

        # No permitir sobreescribir _id
        data.pop("_id", None)

        # Validar estado si viene en la carga
        if "estado" in data:
            estado = data["estado"].lower().strip()
            if estado not in ESTADOS_VALIDOS:
                return jsonify({
                    "error": f"Estado '{estado}' no válido. Opciones: {list(ESTADOS_VALIDOS)}"
                }), 400
            data["estado"] = estado

        # Si se actualizan ítems embebidos, recalcular subtotales y total
        if "items" in data and isinstance(data["items"], list):
            items_embebidos = []
            total = 0.0
            for item in data["items"]:
                cant = int(item.get("cantidad", 1))
                precio = float(item.get("precio_unitario", 0.0))
                subtotal = round(cant * precio, 2)
                total += subtotal
                item_actualizado = {
                    "figura_id": str(item.get("figura_id")),
                    "nombre": item.get("nombre", "Figura 3D"),
                    "cantidad": cant,
                    "precio_unitario": precio,
                    "subtotal": subtotal,
                    "material": item.get("material", "PLA"),
                    "color": item.get("color", "Original"),
                    "escala": item.get("escala", "1:10")
                }
                items_embebidos.append(item_actualizado)
            data["items"] = items_embebidos
            if "total" not in data:
                data["total"] = round(total, 2)

        data["fecha_actualizacion"] = datetime.utcnow().isoformat()

        resultado = pedidos.update_one(
            {"_id": ObjectId(pedido_id)},
            {"$set": data}
        )

        if resultado.matched_count == 0:
            return jsonify({"error": "Pedido no encontrado"}), 404

        pedido_actualizado = pedidos.find_one({"_id": ObjectId(pedido_id)})
        return jsonify({
            "mensaje": "Pedido actualizado con éxito",
            "pedido": serialize_doc(pedido_actualizado)
        }), 200

    except Exception as e:
        return jsonify({"error": f"Error al actualizar pedido: {str(e)}"}), 500


@pedidos_bp.route("/<string:pedido_id>", methods=["DELETE"])
def eliminar_pedido(pedido_id):
    """
    Eliminar un pedido por su ObjectId.
    """
    try:
        if not ObjectId.is_valid(pedido_id):
            return jsonify({"error": "ID de pedido inválido"}), 400

        resultado = pedidos.delete_one({"_id": ObjectId(pedido_id)})
        if resultado.deleted_count == 0:
            return jsonify({"error": "Pedido no encontrado"}), 404

        return jsonify({"mensaje": f"Pedido con ID {pedido_id} eliminado exitosamente"}), 200
    except Exception as e:
        return jsonify({"error": f"Error al eliminar pedido: {str(e)}"}), 500
