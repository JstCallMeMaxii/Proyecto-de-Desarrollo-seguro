# pyrefly: ignore-errors
from flask import Blueprint, jsonify, request  # pyrefly: ignore [missing-import]  # type: ignore
from werkzeug.security import check_password_hash  # pyrefly: ignore [missing-import]  # type: ignore
from db_mongo import usuarios, serialize_doc

# Creación del Blueprint de autenticación (faltaba en el proyecto original)
auth_bp = Blueprint("auth_bp", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Verifica email + contraseña contra la base de datos y devuelve los
    datos del usuario (sin la contraseña) si son correctos.
    No genera un token (JWT) todavía -- el frontend Node guarda el _id
    del usuario en su propia sesión de servidor.
    """
    try:
        data = request.get_json() or {}
        email = data.get("email")
        password = data.get("password")

        if not email or not password:
            return jsonify({"error": "Los campos 'email' y 'password' son requeridos"}), 400

        email_normalizado = email.strip().lower()
        usuario = usuarios.find_one({"email": email_normalizado})

        if not usuario or not check_password_hash(usuario["password"], password):
            return jsonify({"error": "Correo o contraseña incorrectos"}), 401

        if not usuario.get("activo", True):
            return jsonify({"error": "Esta cuenta está desactivada"}), 403

        usuario_sin_password = serialize_doc(usuario)
        usuario_sin_password.pop("password", None)

        return jsonify({
            "mensaje": "Inicio de sesión exitoso",
            "usuario": usuario_sin_password
        }), 200

    except Exception as e:
        return jsonify({"error": f"Error al iniciar sesión: {str(e)}"}), 500