# pyrefly: ignore-errors
from datetime import datetime
from flask import Blueprint, jsonify, request  # pyrefly: ignore [missing-import]  # type: ignore
from bson import ObjectId  # pyrefly: ignore [missing-import]  # type: ignore
from bson.errors import InvalidId  # pyrefly: ignore [missing-import]  # type: ignore
from werkzeug.security import generate_password_hash, check_password_hash
from db_mongo import usuarios, serialize_doc

# Creación del Blueprint de usuarios
usuarios_bp = Blueprint("usuarios_bp", __name__)

ROLES_VALIDOS = {"admin", "vendedor", "cliente"}


@usuarios_bp.route("", methods=["GET"])
@usuarios_bp.route("/", methods=["GET"])
def obtener_usuarios():
    """
    Obtener todos los usuarios.
    Permite filtrar por rol a través de query params: ?rol=admin|vendedor|cliente
    """
    try:
        query = {}
        rol_param = request.args.get("rol")
        if rol_param:
            if rol_param not in ROLES_VALIDOS:
                return jsonify({
                    "error": f"Rol '{rol_param}' no válido. Opciones permitidas: {list(ROLES_VALIDOS)}"
                }), 400
            query["rol"] = rol_param

        lista_usuarios = list(usuarios.find(query))
        return jsonify({
            "total": len(lista_usuarios),
            "usuarios": serialize_doc(lista_usuarios)
        }), 200
    except Exception as e:
        return jsonify({"error": f"Error al obtener usuarios: {str(e)}"}), 500


@usuarios_bp.route("/<string:usuario_id>", methods=["GET"])
def obtener_usuario_por_id(usuario_id):
    """
    Obtener un usuario específico por su ObjectId.
    """
    try:
        if not ObjectId.is_valid(usuario_id):
            return jsonify({"error": "ID de usuario inválido"}), 400

        usuario = usuarios.find_one({"_id": ObjectId(usuario_id)})
        if not usuario:
            return jsonify({"error": "Usuario no encontrado"}), 404

        return jsonify({"usuario": serialize_doc(usuario)}), 200
    except Exception as e:
        return jsonify({"error": f"Error al buscar usuario: {str(e)}"}), 500


@usuarios_bp.route("", methods=["POST"])
@usuarios_bp.route("/", methods=["POST"])
def crear_usuario():
    """
    Crear un nuevo usuario con validación de roles ('admin', 'vendedor', 'cliente').
    """
    try:
        data = request.get_json() or {}

        # Validaciones de campos obligatorios
        nombre = data.get("nombre")
        email = data.get("email")
        password = data.get("password") or data.get("contrasena")
        rol = data.get("rol", "cliente").strip().lower()

        if not nombre or not email or not password:
            return jsonify({
                "error": "Los campos 'nombre', 'email' y 'password' son requeridos"
            }), 400

        # Validación de rol
        if rol not in ROLES_VALIDOS:
            return jsonify({
                "error": f"El rol '{rol}' no es válido. Roles permitidos: {list(ROLES_VALIDOS)}"
            }), 400

        # Verificar si el correo ya existe
        email_normalizado = email.strip().lower()
        if usuarios.find_one({"email": email_normalizado}):
            return jsonify({"error": "El correo electrónico ya está registrado"}), 409

        nuevo_usuario = {
            "nombre": nombre.strip(),
            "email": email_normalizado,
            "password": generate_password_hash(password),  # CORRECCIÓN: hasheada, ya no texto plano
            "rol": rol,
            "telefono": data.get("telefono", ""),
            "direccion": data.get("direccion", ""),
            "activo": data.get("activo", True),
            "fecha_creacion": datetime.utcnow().isoformat()
        }

        resultado = usuarios.insert_one(nuevo_usuario)
        nuevo_usuario["_id"] = resultado.inserted_id
        usuario_respuesta = serialize_doc(nuevo_usuario)
        usuario_respuesta.pop("password", None)  # CORRECCIÓN: no exponer el hash en la respuesta

        return jsonify({
            "mensaje": "Usuario creado exitosamente",
            "usuario": usuario_respuesta
        }), 201

    except Exception as e:
        return jsonify({"error": f"Error al crear usuario: {str(e)}"}), 500


@usuarios_bp.route("/<string:usuario_id>", methods=["PUT"])
def actualizar_usuario(usuario_id):
    """
    Actualizar datos de un usuario por su ObjectId.
    """
    try:
        if not ObjectId.is_valid(usuario_id):
            return jsonify({"error": "ID de usuario inválido"}), 400

        data = request.get_json() or {}
        if not data:
            return jsonify({"error": "No se enviaron datos para actualizar"}), 400

        # Validar rol si se incluye en la actualización
        if "rol" in data:
            rol = data["rol"].strip().lower()
            if rol not in ROLES_VALIDOS:
                return jsonify({
                    "error": f"El rol '{rol}' no es válido. Roles permitidos: {list(ROLES_VALIDOS)}"
                }), 400
            data["rol"] = rol

        # Validar duplicidad de email si se actualiza
        if "email" in data:
            email_normalizado = data["email"].strip().lower()
            existente = usuarios.find_one({"email": email_normalizado, "_id": {"$ne": ObjectId(usuario_id)}})
            if existente:
                return jsonify({"error": "El correo electrónico ya está en uso por otro usuario"}), 409
            data["email"] = email_normalizado

        # Hashear contraseña si viene incluida en la actualización (CORRECCIÓN)
        if "password" in data and data["password"]:
            data["password"] = generate_password_hash(data["password"])
        elif "password" in data:
            data.pop("password")

        # No permitir sobreescribir _id
        data.pop("_id", None)
        data["fecha_actualizacion"] = datetime.utcnow().isoformat()

        resultado = usuarios.update_one(
            {"_id": ObjectId(usuario_id)},
            {"$set": data}
        )

        if resultado.matched_count == 0:
            return jsonify({"error": "Usuario no encontrado"}), 404

        usuario_actualizado = usuarios.find_one({"_id": ObjectId(usuario_id)})
        return jsonify({
            "mensaje": "Usuario actualizado con éxito",
            "usuario": serialize_doc(usuario_actualizado)
        }), 200

    except Exception as e:
        return jsonify({"error": f"Error al actualizar usuario: {str(e)}"}), 500


@usuarios_bp.route("/<string:usuario_id>", methods=["DELETE"])
def eliminar_usuario(usuario_id):
    """
    Eliminar un usuario por su ObjectId.
    """
    try:
        if not ObjectId.is_valid(usuario_id):
            return jsonify({"error": "ID de usuario inválido"}), 400

        resultado = usuarios.delete_one({"_id": ObjectId(usuario_id)})
        if resultado.deleted_count == 0:
            return jsonify({"error": "Usuario no encontrado"}), 404

        return jsonify({"mensaje": f"Usuario con ID {usuario_id} eliminado exitosamente"}), 200
    except Exception as e:
        return jsonify({"error": f"Error al eliminar usuario: {str(e)}"}), 500


@usuarios_bp.route("/login", methods=["POST"])
def login():
    """
    CORRECCIÓN: no existía ningún endpoint de autenticación.
    Verifica email + password y devuelve los datos del usuario (sin el hash)
    si son correctos. El frontend (Node) guarda esos datos en su sesión.
    """
    try:
        data = request.get_json() or {}
        email = data.get("email")
        password = data.get("password")

        if not email or not password:
            return jsonify({"error": "Los campos 'email' y 'password' son requeridos"}), 400

        email_normalizado = email.strip().lower()
        usuario = usuarios.find_one({"email": email_normalizado})

        if not usuario or not check_password_hash(usuario["password"], password):
            return jsonify({"error": "Correo o contraseña incorrectos"}), 401

        if not usuario.get("activo", True):
            return jsonify({"error": "Esta cuenta está desactivada"}), 403

        usuario_respuesta = serialize_doc(usuario)
        usuario_respuesta.pop("password", None)

        return jsonify({
            "mensaje": "Login exitoso",
            "usuario": usuario_respuesta
        }), 200

    except Exception as e:
        return jsonify({"error": f"Error al iniciar sesión: {str(e)}"}), 500
